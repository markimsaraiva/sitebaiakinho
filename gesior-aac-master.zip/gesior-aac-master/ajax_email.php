<?php
define('ONLY_PAGE', true);
$_GET['subtopic'] = 'ajax_email';
$_REQUEST['subtopic'] = 'ajax_email';
include('index.php');