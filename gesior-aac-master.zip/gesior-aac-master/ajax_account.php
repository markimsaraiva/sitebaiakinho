<?php
define('ONLY_PAGE', true);
$_GET['subtopic'] = 'ajax_account';
$_REQUEST['subtopic'] = 'ajax_account';
include('index.php');