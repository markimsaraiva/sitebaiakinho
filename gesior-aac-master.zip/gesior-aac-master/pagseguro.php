<?php
$_GET['subtopic'] = 'pagseguro';
$_REQUEST['subtopic'] = 'pagseguro';
include('index.php');