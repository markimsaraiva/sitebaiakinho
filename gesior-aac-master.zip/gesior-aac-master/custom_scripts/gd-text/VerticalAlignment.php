<?php
namespace GDText;

abstract class VerticalAlignment
{
    const Top = 'top';
    const Bottom = 'bottom';
    const Center = 'center';
}