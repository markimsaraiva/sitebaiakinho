<?php
namespace GDText;

abstract class HorizontalAlignment
{
    const Left = 'left';
    const Right = 'right';
    const Center = 'center';
}