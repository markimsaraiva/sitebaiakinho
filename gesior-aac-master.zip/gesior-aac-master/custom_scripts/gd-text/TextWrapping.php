<?php
namespace GDText;

abstract class TextWrapping
{
    const NoWrap = 1;
    const WrapWithOverflow = 2;
}